import React from 'react'

const Backdrop=props=>(
    <div className="backdrop" >
    </div>
);

export default Backdrop