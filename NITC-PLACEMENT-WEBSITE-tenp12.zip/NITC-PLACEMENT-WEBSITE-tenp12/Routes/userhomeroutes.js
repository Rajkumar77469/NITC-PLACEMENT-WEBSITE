// routes/userStudentRoute.js
// routes/studentRoute.js


// const express = require('express');
// const router = express.Router();
// const {
//     getAllcompany,
 
//   } = require("../Controler/companycontroler");
  
// const studentController = require('../Controler/userStudentController');
// const { getAllCompanyNames }=require("../Controler/getallcompanycontroler")
// const studentbycontroller=require('../Controler/getallstudentscontroler.js')
// // router.get('/student-details/:Email', studentController.getStudentDetailsByEmail);
// router.get('/company-details',getAllCompanyNames);
// // router.get('/studentsby-details',studentbycontroller.getallstudentscontroler);
// router.post("/get-companyss", getAllcompany);
// module.exports = router;
